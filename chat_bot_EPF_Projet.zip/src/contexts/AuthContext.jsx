import React, { createContext, useContext, useState, useEffect } from 'react';
import { isAuthenticated, getUserId, getUserEmail, logout } from '../Services/authService';

const AuthContext = createContext();

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  // Vérifie l'état d'authentification au chargement et à chaque changement dans sessionStorage
  useEffect(() => {
    const checkAuth = () => {
      try {
        if (isAuthenticated()) {
          const email = getUserEmail();
          const id = getUserId();
          
          if (email || id) {
            setUser({
              id: id,
              email: email
            });
            console.log("Utilisateur authentifié trouvé:", email || id);
          } else {
            setUser(null);
            console.log("Token valide mais aucune information utilisateur trouvée");
          }
        } else {
          setUser(null);
          console.log("Aucun utilisateur authentifié");
        }
      } catch (error) {
        console.error("Erreur lors de la vérification de l'authentification:", error);
        setUser(null);
      } finally {
        setLoading(false);
      }
    };
    
    // Observer les changements dans sessionStorage
    const handleStorageChange = (e) => {
      if (e.key === 'auth_token' || e.key === 'user_id' || e.key === 'user_email') {
        checkAuth();
      }
    };
    
    // Vérification initiale
    checkAuth();
    
    // Ajouter l'écouteur d'événement
    window.addEventListener('storage', handleStorageChange);
    
    // Nettoyage
    return () => {
      window.removeEventListener('storage', handleStorageChange);
    };
  }, []);

  // Fonction de connexion
  const login = (userData) => {
    setUser(userData);
  };

  // Fonction de déconnexion
  const handleLogout = () => {
    logout();
    setUser(null);
  };

  return (
    <AuthContext.Provider
      value={{
        isAuthenticated: !!user,
        user,
        login,
        logout: handleLogout,
        loading
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => useContext(AuthContext);