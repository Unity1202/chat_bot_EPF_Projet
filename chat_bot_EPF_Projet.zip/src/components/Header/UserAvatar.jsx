import React from 'react';
import LoginDialog from './LoginDialog';
import LogoutMenu from './LogoutMenu';
import { Avatar, AvatarImage, AvatarFallback } from "../../components/ui/avatar";
import { User } from "lucide-react";
import { useAuth } from '../../contexts/AuthContext';

const UserAvatar = () => {
    const { user, isAuthenticated, logout } = useAuth();

    const getInitials = () => {
        if (!user) return 'U';
        
        const firstName = user.firstName || '';
        const lastName = user.lastName || '';
        
        return `${firstName.charAt(0)}${lastName.charAt(0)}`.toUpperCase() || 'U';
    };

    const renderAvatar = () => {
        if (!isAuthenticated) {
            return (
                <Avatar className="cursor-pointer">
                    <AvatarFallback className="bg-[#FFFFFF] text-[#16698C]">
                        <User className="h-6 w-6" />
                    </AvatarFallback>
                </Avatar>
            );
        }

        // Si l'utilisateur a un avatar, l'afficher, sinon afficher ses initiales
        if (user?.avatar) {
            return (
                <Avatar className="cursor-pointer">
                    <AvatarImage src={user.avatar} alt={user.firstName} />
                    <AvatarFallback>{getInitials()}</AvatarFallback>
                </Avatar>
            );
        }

        return (
            <Avatar className="cursor-pointer">
                <AvatarFallback className="bg-[#15ACCD] text-[#FFFFFF]">
                    {getInitials()}
                </AvatarFallback>
            </Avatar>
        );
    };

    if (!isAuthenticated) {
        return (
            <LoginDialog>
                {renderAvatar()}
            </LoginDialog>
        );
    }

    return (
        <LogoutMenu onLogout={logout} user={user}>
            {renderAvatar()}
        </LogoutMenu>
    );
};

export default UserAvatar;