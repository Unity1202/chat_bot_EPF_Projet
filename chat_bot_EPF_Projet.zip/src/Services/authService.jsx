import { jwtDecode } from 'jwt-decode';
/**
 * Service pour gérer l'authentification des utilisateurs
 */

const API_URL = 'http://localhost:8000/auth';

// Utiliser sessionStorage au lieu de localStorage pour plus de sécurité
const TOKEN_KEY = 'auth_token';
const USER_ID_KEY = 'user_id';
const USER_EMAIL_KEY = 'user_email';

/**
 * Stocke le token d'authentification et les informations essentielles de l'utilisateur
 * @param {string} token - Le JWT token
 */
export const setAuthToken = (token) => {
  if (!token) {
    return;
  }
  
  try {
    // Décoder le token pour extraire les informations utilisateur
    const decoded = jwtDecode(token);
    
    // Stocker uniquement le token et les informations essentielles
    sessionStorage.setItem(TOKEN_KEY, token);
    
    // Stocker l'ID utilisateur s'il existe dans le token
    if (decoded.sub || decoded.id || decoded.user_id) {
      const userId = decoded.sub || decoded.id || decoded.user_id;
      sessionStorage.setItem(USER_ID_KEY, userId);
    }
    
    // Stocker l'email si présent
    if (decoded.email) {
      sessionStorage.setItem(USER_EMAIL_KEY, decoded.email);
    }
    
    return decoded;
  } catch (error) {
    console.error("Erreur lors du décodage du token:", error);
    // Stocker le token brut si on ne peut pas le décoder
    sessionStorage.setItem(TOKEN_KEY, token);
  }
};

/**
 * Récupère le token d'authentification
 * @returns {string|null} - Le token d'authentification ou null
 */
export const getToken = () => {
  return sessionStorage.getItem(TOKEN_KEY);
};

/**
 * Récupère l'ID de l'utilisateur
 * @returns {string|null} - L'ID utilisateur ou null
 */
export const getUserId = () => {
  return sessionStorage.getItem(USER_ID_KEY);
};

/**
 * Récupère l'email de l'utilisateur
 * @returns {string|null} - L'email de l'utilisateur ou null
 */
export const getUserEmail = () => {
  return sessionStorage.getItem(USER_EMAIL_KEY);
};

/**
 * Vérifie si l'utilisateur est authentifié
 * @returns {boolean} - true si l'utilisateur est authentifié
 */
export const isAuthenticated = () => {
  const token = getToken();
  
  if (!token) {
    return false;
  }
  
  try {
    // Vérifier si le token est expiré
    const decoded = jwtDecode(token);
    return decoded.exp > Date.now() / 1000;
  } catch (error) {
    return false;
  }
};

/**
 * Authentifie un utilisateur
 * @param {string} email - Email de l'utilisateur
 * @param {string} password - Mot de passe de l'utilisateur
 * @returns {Promise} - La promesse contenant les informations de l'utilisateur
 */
export const login = async (email, password) => {
  try {
    // Préparation des données d'authentification
    const formData = new URLSearchParams();
    formData.append('username', email);
    formData.append('password', password);
    
    const response = await fetch(`${API_URL}/login`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
        'Accept': 'application/json'
      },
      body: formData
    });
    
    // Gestion des erreurs
    if (!response.ok) {
      const errorData = await response.json().catch(() => ({}));
      throw new Error(errorData.detail || `Erreur d'authentification: ${response.status}`);
    }
    
    const data = await response.json();
    
    // Stocker le token de manière sécurisée
    if (data.access_token) {
      setAuthToken(data.access_token);
    }
    
    return {
      token: data.access_token,
      user: {
        email: email,
        id: getUserId() // Récupérer l'ID depuis le token décodé
      }
    };
  } catch (error) {
    console.error('Erreur de connexion:', error);
    throw error;
  }
};



/**
 * Inscrit un nouvel utilisateur
 * @param {Object} userData - Données de l'utilisateur
 * @returns {Promise} - La promesse contenant les informations de l'utilisateur créé
 */
export const signup = async (userData) => {
    try {
      console.log('Données envoyées pour inscription:', userData);
      
      // Créer un objet pour l'envoi en JSON (le backend semble attendre ce format)
      const payload = {
        email: userData.email,
        // Utiliser firstName + lastName comme username s'il n'est pas fourni
        username: userData.username || `${userData.firstName}_${userData.lastName}`.toLowerCase().replace(/\s+/g, '_'),
        password: userData.password,
        // Ajouter les champs supplémentaires si l'API les attend
        first_name: userData.firstName,
        last_name: userData.lastName
      };
      
      // Log pour déboguer
      console.log('Données pour inscription:', payload);
      
      const response = await fetch(`${API_URL}/register`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json', // Utiliser JSON au lieu de x-www-form-urlencoded
          'Accept': 'application/json'
        },
        body: JSON.stringify(payload) // Convertir en JSON
      });
      
      // Tenter de récupérer la réponse en tant que JSON
      let data;
      const contentType = response.headers.get("content-type");
      if (contentType && contentType.indexOf("application/json") !== -1) {
        data = await response.json();
      } else {
        const text = await response.text();
        console.log("Réponse non-JSON:", text);
        data = { message: text };
      }
      
      if (!response.ok) {
        console.error('Erreur d\'inscription:', data);
        // Pour une meilleure gestion des erreurs avec les APIs FastAPI
        if (data.detail && Array.isArray(data.detail)) {
          const errorMessages = data.detail.map(err => 
            `${err.msg} ${err.loc ? `(${err.loc.join('.')})` : ''}`
          ).join(', ');
          throw new Error(errorMessages);
        } else {
          throw new Error(data.message || data.detail || `Erreur d'inscription: ${response.status}`);
        }
      }
      
      // Stocker le token dans le localStorage si l'API le retourne lors de l'inscription
      if (data.token || data.access_token) {
        const token = data.token || data.access_token;
        localStorage.setItem('authToken', token);
        
        // Stocker les informations de l'utilisateur
        const user = {
          email: userData.email,
          username: payload.username, // Utiliser le nom d'utilisateur créé
          firstName: userData.firstName,
          lastName: userData.lastName,
          // Si l'API renvoie plus d'informations sur l'utilisateur, les ajouter ici
          ...(data.user || {})
        };
        
        localStorage.setItem('user', JSON.stringify(user));
      }
      
      return data;
    } catch (error) {
      console.error("Erreur d'inscription:", error);
      throw error;
    }
};

/**
 * Déconnecte l'utilisateur
 */
export const logout = () => {
    sessionStorage.removeItem(TOKEN_KEY);
    sessionStorage.removeItem(USER_ID_KEY);
    sessionStorage.removeItem(USER_EMAIL_KEY);
  };

/**
 * Vérifie si l'utilisateur est connecté
 * @returns {boolean} - true si l'utilisateur est connecté
 */

/**
 * Récupère l'utilisateur connecté
 * @returns {Object|null} - Les informations de l'utilisateur ou null
 */
export const getCurrentUser = () => {
  const user = localStorage.getItem('user');
  return user ? JSON.parse(user) : null;
};

/**
 * Récupère le token d'authentification
 * @returns {string|null} - Le token d'authentification ou null
 */
