/**
 * Service pour gérer les communications avec l'API de chat
 */
import { getToken } from './authService';

const API_URL = 'http://localhost:8000/api/chat/query';
const API_URL2 = 'http://localhost:8000/api/chat';


  
  
  
 

/**
 * Envoie une requête au backend et récupère la réponse
 * @param {string} query - La question de l'utilisateur
 * @param {string} conversationId - L'ID de conversation optionnel pour continuer une conversation existante
 * @returns {Promise} - La promesse contenant la réponse du backend
 */
export const sendQuery = async (query, conversationId = null) => {
  try {
    const payload = { query };
    
    // Ajouter l'ID de conversation s'il existe
    if (conversationId) {
      payload.conversation_id = conversationId;
    }
    
    // Récupérer le token d'authentification
    const token = getToken();
    
    // Préparer les en-têtes avec ou sans token
    const headers = {
      'Content-Type': 'application/json',
      'Accept': 'application/json'
    };
    
    if (token) {
      headers['Authorization'] = `Bearer ${token}`;
    }
    
    const response = await fetch(API_URL, {
      method: 'POST',
      headers,
      body: JSON.stringify(payload)
    });
    
    if (!response.ok) {
      const errorData = await response.json().catch(() => ({}));
      throw new Error(errorData.detail || `Erreur API: ${response.status}`);
    }
    
    return await response.json();
  } catch (error) {
    console.error('Erreur lors de l\'envoi de la requête:', error);
    throw error;
  }
};

/**
 * Récupère l'ID de l'utilisateur actuellement connecté
 * Cette fonction sert de médiateur pour obtenir l'ID en essayant différentes sources
 */
const getCurrentUserId = () => {
  // 1. Essayer d'abord de récupérer l'ID depuis sessionStorage (méthode préférée)
  const userId = sessionStorage.getItem('user_id');
  if (userId) {
    return userId;
  }
  
  // 2. Si pas d'ID dans sessionStorage, essayer de récupérer l'email et générer un ID
  const email = sessionStorage.getItem('user_email');
  if (email) {
    // Générer un hash numérique basé sur l'email
    let hashCode = 0;
    const cleanEmail = email.toLowerCase();
    for (let i = 0; i < cleanEmail.length; i++) {
      const char = cleanEmail.charCodeAt(i);
      hashCode = ((hashCode << 5) - hashCode) + char;
      hashCode = hashCode & hashCode; // Conversion en 32bit integer
    }
    const generatedId = Math.abs(hashCode);
    console.log(`ID généré à partir de l'email (${email}): ${generatedId}`);
    return generatedId.toString();
  }
  
  // 3. Dernière tentative: vérifier dans localStorage (pour la compatibilité avec l'ancien code)
  try {
    const userJson = localStorage.getItem('user');
    if (userJson) {
      const user = JSON.parse(userJson);
      if (user.id) return user.id;
      if (user.email) {
        // Même logique de génération d'ID à partir de l'email
        let hashCode = 0;
        const cleanEmail = user.email.toLowerCase();
        for (let i = 0; i < cleanEmail.length; i++) {
          const char = cleanEmail.charCodeAt(i);
          hashCode = ((hashCode << 5) - hashCode) + char;
          hashCode = hashCode & hashCode;
        }
        const generatedId = Math.abs(hashCode);
        console.log(`ID généré à partir de l'email stocké (${user.email}): ${generatedId}`);
        return generatedId.toString();
      }
    }
  } catch (e) {
    console.error("Erreur lors du parsing du JSON utilisateur:", e);
  }
  
  console.error("Impossible de trouver ou générer un ID utilisateur");
  return null;
};

/**
 * Récupère l'historique des conversations de l'utilisateur
 * @returns {Promise} - La promesse contenant l'historique
 */
export const getConversationHistory = async () => {
  try {
    const token = getToken();
    
    if (!token) {
      console.log("Pas de token d'authentification trouvé");
      return []; // Retourner un tableau vide si pas de token
    }
    
    const userId = getCurrentUserId();

    if (!userId) {
      console.error("Aucun utilisateur trouvé dans le localStorage");
      return [];
    }
    
    
    // Utiliser notre fonction utilitaire pour trouver l'ID
    
    if (!userId) {
      console.error("ID utilisateur non trouvé");
      // Pour le développement, on peut retourner des données factices
    }
    
    console.log("Récupération des conversations pour l'utilisateur:", userId);
    
    // Utiliser l'ID de l'utilisateur dans l'URL
    const response = await fetch(`${API_URL2}/conversations/${userId}`, {
      method: 'GET',
      headers: {
        'Accept': 'application/json',
        'Authorization': `Bearer ${token}`
      }
    });
    
    if (!response.ok) {
      console.error(`Erreur API (${response.status}):`, await response.text());
      throw new Error(`Erreur API: ${response.status}`);
    }
    
    // Transformer les données pour correspondre à notre structure d'affichage
    const data = await response.json();
    return data.map(conv => ({
      id: conv.conversation_id,
      title: conv.title || `Conversation #${conv.conversation_id.substring(0, 8)}...`,
      preview: conv.last_message || "Aucun message",
      date: conv.created_at || new Date().toISOString(),
      category: assignCategory(conv.category || 'other')
    }));
    
  } catch (error) {
    console.error('Erreur lors de la récupération de l\'historique:', error);
    // En cas d'erreur en production, retourner un tableau vide
    // En développement, on peut retourner des données factices
  }
};

/**
 * Fonction qui génère des données factices pour le développement
 */


/**
 * Attribue une catégorie selon notre système de classification
 * @param {string} apiCategory - La catégorie retournée par l'API
 * @returns {string} - La catégorie normalisée pour notre interface
 */
const assignCategory = (apiCategory) => {
  if (!apiCategory) return 'other';
  
  // Mapper les catégories de l'API vers nos catégories d'affichage
  const categoryMap = {
    'treasury': 'treasury',
    'financial': 'treasury',
    'finance': 'treasury',
    'organizational': 'organisational',
    'organisation': 'organisational',
    'structure': 'organisational',
    'management': 'organisational',
    'other': 'other',
    'general': 'other',
    'legal': 'other',
    'juridique': 'other'
  };
  
  return categoryMap[apiCategory.toLowerCase()] || 'other';
};

/**
 * Récupère une conversation spécifique avec tous ses messages
 * @param {string} conversationId - L'ID de la conversation à récupérer
 * @returns {Promise} - La promesse contenant les détails de la conversation
 */
export const getConversationById = async (conversationId) => {
  try {
    const token = getToken();
    
    if (!token) {
      return null;
    }
    
    // Utiliser l'URL correcte pour récupérer une conversation spécifique
    const response = await fetch(`${API_URL2}/conversation/${conversationId}`, {
      method: 'GET',
      headers: {
        'Accept': 'application/json',
        'Authorization': `Bearer ${token}`
      }
    });
    
    if (!response.ok) {
      console.error(`Erreur API (${response.status}):`, await response.text());
      throw new Error(`Erreur API: ${response.status}`);
    }
    
    const conversation = await response.json();
    
    // Transformer les messages dans le format attendu par notre application
    return {
      id: conversation.conversation_id,
      title: conversation.title,
      category: assignCategory(conversation.category || 'other'),
      messages: (conversation.messages || []).map((msg, index) => ({
        id: msg.message_id || index,
        text: msg.content,
        sender: msg.role === 'user' ? 'user' : 'bot',
        timestamp: msg.timestamp || new Date().toISOString(),
        sources: msg.sources || []
      })),
      conversationId: conversation.conversation_id
    };
    
  } catch (error) {
    console.error('Erreur lors de la récupération de la conversation:', error);
    return null;
  }
};

/**
 * Supprime une conversation
 * @param {string} conversationId - L'ID de la conversation à supprimer
 * @returns {Promise<boolean>} - true si la suppression a réussi
 */
export const deleteConversation = async (conversationId) => {
  try {
    const token = getToken();
    
    if (!token) {
      return false;
    }
    
    // Utiliser l'URL correcte pour supprimer une conversation
    const response = await fetch(`${API_URL2}/conversation/${conversationId}`, {
      method: 'DELETE',
      headers: {
        'Accept': 'application/json',
        'Authorization': `Bearer ${token}`
      }
    });
    
    if (!response.ok) {
      console.error(`Erreur API (${response.status}):`, await response.text());
    }
    
    return response.ok;
  } catch (error) {
    console.error('Erreur lors de la suppression de la conversation:', error);
    return false;
  }
};